# NetBox Tools Plugin

A plugin for NetBox that adds utilities like:

- Documentation Reviewer
- Serial Number Checker
- Custom Jobs and Views

## Installation

```bash
pip install git+https://github.com/yourusername/netbox-tools.git

then add to your NetBox configuration:

PLUGINS = ['nbtools']

Compatibility:
Tested with Netbox 4.3.5 and above.
